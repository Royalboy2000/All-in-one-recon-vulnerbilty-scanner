# Application Escape and Breakout

:warning: Content of this page has been moved to [InternalAllTheThings/cheatsheets/escape-breakout](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/)

- [Gaining a command shell](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#gaining-a-command-shell)
- [Sticky Keys](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#sticky-keys)
- [Dialog Boxes](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#dialog-boxes)
    - [Creating new files](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#creating-new-files)
    - [Open a new Windows Explorer instance](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#open-a-new-windows-explorer-instance)
    - [Exploring Context Menus](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#exploring-context-menus)
    - [Save as](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#save-as)
    - [Input Boxes](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#input-boxes)
    - [Bypass file restrictions](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#bypass-file-restrictions)
- [Internet Explorer](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#internet-explorer)
- [Shell URI Handlers](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#shell-uri-handlers)
- [References](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/escape-breakout/#references)
