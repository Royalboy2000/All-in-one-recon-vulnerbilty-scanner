# CRITICAL DISCOVERY: Old Domain Still Active

## wearesocial.net Domain Analysis

**Main domain:** Redirects to wearesocial.com (301)
**DNS:** 141.193.213.20, 141.193.213.21

## Old Subdomains Discovered (31 total)

| Subdomain | Status | Notes |
|-----------|--------|-------|
| **helpdesk.wearesocial.net** | ✅ ACTIVE | Redirects to Okta login (172.66.0.145) |
| jenkins.wearesocial.net | ❌ No DNS | Potential subdomain takeover |
| remote.wearesocial.net | ❌ No DNS | Potential subdomain takeover |
| zentral.wearesocial.net | ❌ No DNS | Potential subdomain takeover |
| ad.wearesocial.net | 🔍 Unknown | Active Directory reference |
| lonut07.ad.wearesocial.net | 🔍 Unknown | Internal hostname leaked |
| lonsrv01.wearesocial.net | 🔍 Unknown | London server |

## Internal Hostnames Leaked

From SSL certificates on old domain:
```
apollo.hi.wearesocial.net
lonut07.ad.wearesocial.net  ← London user/computer?
lonsrv01.wearesocial.net    ← London server 01
```

**Implication:** Internal naming convention exposed.

## Subdomain Takeover Risk

Subdomains with SSL certs but no DNS resolution:
- jenkins.wearesocial.net (CI/CD)
- remote.wearesocial.net (VPN?)
- zentral.wearesocial.net (MDM - device management)
- ship.wearesocial.net
- havethis.wearesocial.net

**Attack:** Register these on cloud providers if CNAME still points to dead resources.

## Active Helpdesk Subdomain

`helpdesk.wearesocial.net` → Okta login page
- Could be used for lookalike phishing domain
- SSL cert valid for wearesocial.net wildcard

---

## Updated Attack Vectors

1. **Subdomain takeover** on jenkins/remote/zentral
2. **Phishing using helpdesk.wearesocial.net** lookalike
3. **Internal recon** using leaked hostname patterns
4. **Social engineering** via 93digital contractor relationship
