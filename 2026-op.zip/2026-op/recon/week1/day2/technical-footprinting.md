# Week 1 Day 2 - Technical Footprinting Report
**Date:** 2026-01-06
**Target:** wearesocial.com

---

## Shodan Findings

### iris.wearesocial.com / iris-backend.wearesocial.com (54.74.35.217)

| Field | Value |
|-------|-------|
| IP | 54.74.35.217 |
| Location | Dublin, Ireland |
| Provider | Amazon Technologies Inc. (AWS EU-West-1) |
| Open Ports | 80/tcp, 443/tcp |
| Web Server | Apache httpd 2.4.58 (Ubuntu) |
| SSL Issuer | Let's Encrypt (E7) |
| SSL Cert CN | iris.wearesocial.com |

### ⚠️ VULNERABILITIES DETECTED (37 CVEs)

**Critical/High:**
- CVE-2024-38476 - Apache SSRF/Info Disclosure (2.4.59 and earlier)
- CVE-2024-38475 - Apache mod_rewrite vulnerability
- CVE-2024-38474 - Apache vulnerability
- CVE-2024-38473 - Apache vulnerability
- CVE-2024-38472 - Apache vulnerability
- CVE-2024-27316 - Apache HTTP/2 DoS
- CVE-2024-24795 - Apache vulnerability
- CVE-2024-40898 - Apache vulnerability

**CVE-2024-38476 Details:**
> "Vulnerability in core of Apache HTTP Server 2.4.59 and earlier are vulnerable to information disclosure, SSRF or local script execution via backend applications whose response headers are malicious or exploitable."
> **Fix:** Upgrade to Apache 2.4.60+

---

## Technology Stack (httpx + Shodan)

| Subdomain | Status | Server | Technologies |
|-----------|--------|--------|--------------|
| iris.wearesocial.com | 200 | Apache/2.4.58 | Apache, Google Font API, Ubuntu |
| iris-backend.wearesocial.com | 200 | Apache/2.4.58 | Apache, Ubuntu, Laravel |
| justlaunched.wearesocial.com | 200 | nginx | Laravel, Nginx, PHP, Statamic CMS |
| thinkforward2022.wearesocial.com | 200 | AmazonS3 | AWS CloudFront, S3, Bootstrap |
| thinkforward2023.wearesocial.com | 200 | AmazonS3 | AWS CloudFront, S3, Bootstrap |
| ar.wearesocial.com | 200 | AmazonS3 | AWS CloudFront, S3 |
| learning.wearesocial.com | 403 | cloudflare | Cloudflare Bot Management |
| wearesocial.com | 403 | cloudflare | Cloudflare Bot Management |
| opscimbridge.wearesocial.com | 307 | - | Redirect (SCIM) |
| recentlyonair.wearesocial.com | 301 | nginx | Nginx |

---

## HTTP Security Headers Analysis

### iris-backend.wearesocial.com

```
Server: Apache/2.4.58 (Ubuntu)
Set-Cookie: XSRF-TOKEN=...; secure; samesite=lax
Set-Cookie: we_are_social_session=...; secure; httponly; samesite=lax
```

**Missing Security Headers:**
- ❌ X-Frame-Options (Clickjacking risk)
- ❌ X-Content-Type-Options
- ❌ Content-Security-Policy
- ❌ Strict-Transport-Security (HSTS)
- ❌ X-XSS-Protection

---

## Infrastructure Summary

| Component | Technology | Version | Vulnerable? |
|-----------|------------|---------|-------------|
| Web Server (iris) | Apache | 2.4.58 | ⚠️ YES - 37 CVEs |
| Backend Framework | Laravel | Unknown | Check version |
| CMS (justlaunched) | Statamic | Unknown | Check version |
| CDN (main site) | Cloudflare | - | Protected |
| Static Sites | AWS S3/CloudFront | - | Low risk |
| SSO | Okta | v1 pipeline | Weak config |
| Email | Google Workspace | - | N/A |
| Identity (M365) | Azure AD | Federated | Okta SSO |

---

## Attack Vectors Identified

### 1. Apache SSRF (CVE-2024-38476) - HIGH
- Target: iris-backend.wearesocial.com
- Impact: SSRF, info disclosure, potential RCE
- Requires: Malicious backend response headers

### 2. Laravel Misconfigurations - MEDIUM
- Debug mode check needed
- Exposed routes/API endpoints
- Session handling vulnerabilities

### 3. Missing Security Headers - LOW
- Clickjacking via iframe embedding
- XSS if input validation weak

### 4. Device Code Phishing - HIGH (from Day 1)
- M365 federated to Okta
- No FastPass/phishing resistance

---

## Recommended Next Steps

1. [ ] Check Laravel version on iris-backend (debug page, error messages)
2. [ ] Test Apache SSRF (CVE-2024-38476) carefully
3. [ ] Directory bruteforce on iris-backend (Day 4)
4. [ ] Check for Laravel .env exposure via path traversal
5. [ ] Enumerate API endpoints

---

## Files Generated
- technical-footprinting.md (this file)
- shodan-iris.txt
- httpx-results.txt
