# Week 1 Day 2 - Technical Footprinting Summary
**Date:** 2026-01-06
**Target:** wearesocial.com
**Objective:** Shodan/Censys search, Technology fingerprinting

---

## Top 7 Attack Vectors Identified

1. **MySQL Exposed (85.92.91.11:3306)** → Direct database access, no WAF
2. **Apache SSRF CVE-2024-38476** → iris-backend.wearesocial.com (37 CVEs total)
3. **cPanel/WHM Exposed (85.92.91.11)** → Admin panels on ports 2082-2087
4. **SSH on 5 Servers** → Brute force / credential stuffing potential
5. **WordPress Multisite** → Single vuln = all regional sites compromised
6. **FTP Exposed (85.92.91.11:21)** → File upload / webshell potential
7. **Non-standard SSH (51.178.16.62:2832)** → Hidden service, may be overlooked

---

## Critical Infrastructure Findings

### Servers Discovered: 7 Total

| IP | Hostname | Location | Critical Ports |
|----|----------|----------|----------------|
| 85.92.91.11 | wdl8.wdl8.co.uk | UK | **22 ports!** MySQL, FTP, cPanel |
| 54.74.35.217 | iris.wearesocial.com | Ireland | 22, 80, 443 (37 CVEs) |
| 54.220.182.225 | justlaunched.wearesocial.com | Ireland | 22, 80, 443 |
| 51.178.16.62 | OVH France | France | 25, 80, 443, **2832/SSH** |
| 18.191.203.70 | WordPress US | Ohio | 22, 80, 443 |
| 34.255.93.210 | recentlyonair | Ireland | 22, 80, 443 |
| 34.185.128.83 | opscimbridge | Germany (GCP) | 80, 443 |

### Vulnerability Count

| Server | CVE Count | Severity |
|--------|-----------|----------|
| iris-backend (54.74.35.217) | **37** | Critical |
| WordPress (18.191.203.70) | Unknown | Check plugins |
| UK cPanel (85.92.91.11) | Unknown | Likely many |

---

## Technology Stack Confirmed

| Category | Technology | Notes |
|----------|------------|-------|
| Web Server | Apache 2.4.58 | VULNERABLE - 37 CVEs |
| Backend | Laravel (PHP) | iris-backend, justlaunched |
| CMS | WordPress Multisite | Main site, WP Engine hosted |
| CMS | Statamic | justlaunched.wearesocial.com |
| CDN/WAF | Cloudflare | Main site protected |
| Hosting | AWS, OVH, UK NOC | Multi-cloud |
| Email | Google Workspace | DMARC Reject policy |
| SSO | Okta → M365 Federation | No FastPass (weak) |
| CRM | Salesforce, Apollo IO | Customer data |
| Collab | Slack, Zoom, Dropbox | High-value targets |

---

## Security Posture Analysis

### Strong Controls
- ✅ DMARC Reject (email spoofing blocked)
- ✅ Cloudflare Bot Management (main site)
- ✅ HSTS enabled
- ✅ SSL by default

### Weak Points
- ❌ MySQL 3306 exposed to internet
- ❌ cPanel admin panels exposed
- ❌ SSH on 5+ servers
- ❌ Apache 2.4.58 with 37 CVEs
- ❌ Missing security headers on iris-backend
- ❌ Okta without FastPass (phishing vulnerable)
- ❌ FTP exposed

---

## Attack Path Priority Matrix

| Vector | Difficulty | Impact | Priority |
|--------|------------|--------|----------|
| MySQL Direct Access | Easy | Critical | **#1** |
| Apache SSRF (CVE-2024-38476) | Medium | High | **#2** |
| cPanel Brute Force | Easy | Critical | **#3** |
| Device Code Phishing | Medium | Critical | **#4** |
| WordPress Plugin Vulns | Medium | High | **#5** |
| SSH Brute Force | Hard | High | **#6** |
| FTP Upload | Easy | Medium | **#7** |

---

## Files Generated

| File | Contents |
|------|----------|
| technical-footprinting.md | Detailed Shodan/httpx analysis |
| shodan-iris.txt | 37 CVEs for Apache 2.4.58 |
| httpx-results.txt | 15 subdomains with tech stack |
| censys-results.txt | 7 servers, 22 ports on UK server |
| builtwith-summary.txt | CMS, analytics, integrations |
| day2-summary.md | This file |

---

## Key Metrics

| Metric | Value |
|--------|-------|
| Servers discovered | 7 |
| Total open ports | 40+ |
| CVEs identified | 37 (Apache alone) |
| Live subdomains | 6 (not behind Cloudflare) |
| SSH endpoints | 5 |
| Exposed databases | 1 (MySQL) |
| Admin panels | 4+ (cPanel/WHM) |

---

## Day 2 Score: 9.5/10

**Exceptional findings:**
- MySQL database directly exposed to internet (85.92.91.11:3306)
- UK hosting server is a goldmine with 22 open ports
- Apache server has 37 known CVEs including critical SSRF
- Multiple SSH endpoints for potential brute force
- WordPress Multisite = single compromise affects all regional sites
- DMARC Reject confirms Device Code phishing is best initial access vector

**What exceeded expectations:**
- Found completely exposed UK cPanel server (wasn't in initial subdomain list)
- OVH France server with hidden SSH on port 2832
- WordPress in US with Contact Form 7 (known vuln history)

**Minor gaps:**
- Laravel/Statamic versions still unknown
- Need to validate MySQL is actually accessible (Week 3)

---

## Recommended Next Steps

1. [ ] Week 3 Day 2: Validate MySQL connectivity (no auth attempt)
2. [ ] Week 3 Day 2: Confirm cPanel is reachable
3. [ ] Week 3 Day 3: Research CVE-2024-38476 exploit availability
4. [ ] Week 1 Day 3: Check GitHub for leaked creds to these servers
5. [ ] Week 2: Set up infrastructure for exploitation phase
