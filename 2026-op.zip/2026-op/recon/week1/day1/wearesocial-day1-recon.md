# Day 1 Reconnaissance Report - wearesocial.com
**Date:** 2026-01-05
**Target:** We Are Social (wearesocial.com)
**Objective:** LinkedIn & Org Chart Mapping / Digital Footprinting

---

## Executive Summary
We Are Social is a global socially-led creative agency with offices in NY, LA, and multiple international locations. They use Google Workspace for email and various SaaS platforms.

---

## Email Intelligence

### Email Format Identified
```
{first}.{last}@wearesocial.com
```

### Emails Discovered
| Email | Source |
|-------|--------|
| jane.doe@wearesocial.com | theHarvester |

### Email Infrastructure
- **Provider:** Google Workspace (G Suite)
- **MX Records:**
  - aspmx.l.google.com (Priority 10)
  - alt1.aspmx.l.google.com (Priority 20)
  - alt2.aspmx.l.google.com (Priority 20)
  - aspmx2-5.googlemail.com (Priority 30)

### SPF Record
```
v=spf1 include:_spf.google.com include:servers.mcsv.net include:spf.sendinblue.com ~all
```

---

## SaaS/Third-Party Services Identified (from TXT records)

| Service | Evidence |
|---------|----------|
| Google Workspace | MX records, SPF |
| Mailchimp | servers.mcsv.net in SPF |
| Sendinblue | TXT verification + SPF |
| DocuSign | docusign=a9111f8c-4198-4d52-98a8-b30b4febbec5 |
| Dropbox | dropbox-domain-verification=3tu3qm1h2371 |
| Zoom | ZOOM_verify_SC2dfCV4SKyJT1yHWiO7Mw |
| Facebook Workplace | workplace-domain-verification |
| Apple Business | apple-domain-verification |
| Extensis (Font mgmt) | extensis-domain-verification |
| Okta SSO | wearesocial.okta.com discovered |

---

## Infrastructure

### DNS Hosting
- AWS Route53 (ns-*.awsdns-*.com/net/org/co.uk)

### Domain Registration
- Registrar: DreamHost
- Abuse Contact: domain-abuse@dreamhost.com

### ASNs Identified
- AS13335 (Cloudflare)
- AS16509 (Amazon AWS)
- AS200651
- AS209242  
- AS38099
- AS47583

---

## Subdomains Discovered (72 total)

### Live & Interesting Targets
| Subdomain | IP | Tech Stack | Notes |
|-----------|-----|------------|-------|
| iris.wearesocial.com | 54.74.35.217 | Apache, Ubuntu | Internal app |
| iris-backend.wearesocial.com | 54.74.35.217 | Apache, Laravel | API backend |
| learning.wearesocial.com | 141.193.213.20 | Cloudflare | LMS - Okta SSO |
| justlaunched.wearesocial.com | 54.220.182.225 | Laravel, Statamic, Nginx | CMS |
| thinkforward2022.wearesocial.com | 13.33.67.16 | AWS S3, CloudFront | Static site |
| ar.wearesocial.com | 13.33.252.108 | AWS S3 | AR app v1.0.129 |
| staging.wearesocial.com | 34.241.50.75 | - | Staging env |
| staging.cn.wearesocial.com | 54.222.211.97 | - | China staging |
| chat.wearesocial.com | 52.19.61.149 | - | Chat service |
| digitalreport.wearesocial.com | 34.254.71.56 | - | Reports |
| candidature.wearesocial.com | 18.185.118.88 | - | Recruitment? |
| opscimbridge.wearesocial.com | 34.185.128.83 | - | SCIM provisioning |
| mail.wearesocial.com | ghs.googlehosted.com | Google | Mail |
| iamsocial.wearesocial.com | - | Google MX | Secondary domain |

### Cloudflare Protected (403)
- www.wearesocial.com
- thinkforward.wearesocial.com
- bravingthebacklash.wearesocial.com
- wearedesign.wearesocial.com

---

## IP Addresses

### Primary IPs
```
141.193.213.20 (Cloudflare)
141.193.213.21 (Cloudflare)
185.247.225.10
76.76.21.21
76.76.21.93
76.223.59.26
```

### AWS Infrastructure
```
34.241.80.72
34.252.184.59
52.215.22.186
52.38.173.188
52.48.228.165
3.131.87.202
54.74.35.217 (iris backend)
54.220.182.225 (justlaunched)
```

---

## Global Presence (from URLs)
- US (wearesocial.com/us/)
- UK (wearesocial.com/uk/)
- France (wearesocial.com/fr/)
- Germany (wearesocial.com/de/)
- Italy (wearesocial.com/it/)
- Netherlands
- Spain (wearesocial.com/es/)
- Canada (wearesocial.com/ca-en/)
- Australia (wearesocial.com/au/)
- Singapore (wearesocial.com/sg/)
- Hong Kong (wearesocial.com/hk/)
- Indonesia (wearesocial.com/id/)
- Thailand
- China (staging.cn.wearesocial.com)
- UAE (wearesocial.com/ae/)
- Middle East (wearesocial.com/me/)

---

## Attack Surface Summary

### High-Value Targets
1. **iris.wearesocial.com** - Internal app on Apache/Ubuntu (not behind Cloudflare)
2. **iris-backend.wearesocial.com** - Laravel API (same IP as iris)
3. **learning.wearesocial.com** - LMS with Okta SSO integration
4. **staging.wearesocial.com** - Staging environment
5. **opscimbridge.wearesocial.com** - SCIM bridge (identity provisioning)

### Authentication Points
- Okta SSO: wearesocial.okta.com
- Google Workspace
- Learning platform (Okta-integrated)

---

## Phishing Resistance Assessment

### How We Checked
```bash
curl -s "https://wearesocial.okta.com/.well-known/okta-organization" | jq .
```

### Results
```json
{
  "id": "00okjju0hfYCCNZDHURH",
  "pipeline": "v1",
  "settings": {
    "pssoEnabled": false,
    "desktopMFAEnabled": false,
    "itpEnabled": false
  }
}
```

### Interpretation
| Setting | Value | Meaning |
|---------|-------|---------|  
| pssoEnabled | **false** | Okta FastPass (FIDO2/WebAuthn) NOT enabled |
| desktopMFAEnabled | **false** | Device-bound MFA NOT required |
| itpEnabled | **false** | Identity Threat Protection NOT active |
| pipeline | **v1** | Legacy auth pipeline (less secure than v2) |

### Verdict: NO PHISHING-RESISTANT MFA ❌

- ❌ No Okta FastPass (FIDO2/WebAuthn)
- ❌ No hardware security keys required
- ❌ No device trust/certificate-based auth
- ❌ No Identity Threat Protection (behavioral analysis)
- ✅ Likely using standard Okta Verify push or TOTP (bypassable)

### Attack Implications
1. **Device Code Phishing WILL WORK** - User completes MFA on real site, attacker gets token
2. **MFA Fatigue Attacks Possible** - Push spam until user approves
3. **Real-time Phishing (Evilginx) Possible** - No device binding to prevent replay

---

### Potential Entry Points
1. **Device Code Phishing** - Primary vector (no phishing resistance)
2. Laravel apps (iris-backend, justlaunched) - check for misconfigs
3. Staging environments - often less secured
4. SCIM bridge - identity management endpoint

---

## Next Steps (Day 2 - Technical Footprinting)
- [ ] Full port scan on non-Cloudflare IPs (iris, staging)
- [ ] Technology fingerprinting on discovered apps
- [ ] Check for exposed admin panels
- [ ] GitHub/GitLab search for code leaks
- [ ] LinkedIn profile enumeration (manual or alternative tools)

---

## Tools Used
- theHarvester
- subfinder
- assetfinder
- httpx
- dig
- whois

---

## Raw Data Files
- See: /home/samir/2026-op/recon/day1/
